package com.example.alok.navjeevan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Articles extends AppCompatActivity {
    ImageView article1;
    ImageView article2;
    ImageView article3;
    ImageView article4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_articles);
        getSupportActionBar().setTitle("Articles");
        article1=(ImageView)findViewById(R.id.article1);
        article2=(ImageView)findViewById(R.id.article2);
        article3=(ImageView)findViewById(R.id.article3);
        article4=(ImageView)findViewById(R.id.article4);
        article1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View paramAnonymousView) {
                Intent intent=new Intent(Articles.this,Article2.class);
                startActivity(intent);
            }
        });
        article2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View paramAnonymousView) {
                Intent intent=new Intent(Articles.this,Article1.class);
                startActivity(intent);
            }
        });
        article3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View paramAnonymousView) {
                Intent intent=new Intent(Articles.this,Article3.class);
                startActivity(intent);
            }
        });
        article4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View paramAnonymousView) {
                Intent intent=new Intent(Articles.this,Article4.class);
                startActivity(intent);
            }
        });
    }
}
