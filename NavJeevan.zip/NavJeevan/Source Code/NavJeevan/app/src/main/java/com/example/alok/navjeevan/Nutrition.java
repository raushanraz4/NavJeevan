package com.example.alok.navjeevan;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Nutrition extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition);
        getSupportActionBar().setTitle("Nutrition");
    }
    public void babydiet(View view){
        Intent intent=new Intent(Nutrition.this,Baby.class);
        startActivity(intent);
    }
    public void motherdiet(View view){
        Intent intent=new Intent(Nutrition.this,Mother.class);
        startActivity(intent);
    }
}
